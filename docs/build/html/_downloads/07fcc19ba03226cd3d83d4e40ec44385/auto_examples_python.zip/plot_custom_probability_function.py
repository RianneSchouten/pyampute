"""
============================================
An example about custom probability function
============================================
"""

import numpy as np